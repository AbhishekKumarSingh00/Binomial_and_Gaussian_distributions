from setuptools import setup

setup(name='dist_prob_binomial_gaussian',
      version='0.1',
      description='Binomial and Gaussian distributions',
      packages=['dist_prob_binomial_gaussian'],
      author = 'Abhishek Kumar Singh',
      author_email = 'abhishek.kumar.singh2101@gmail.com',
      zip_safe=False)
